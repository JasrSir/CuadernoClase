<?php

/**
 * User: JuanAntonio
 */
class ControlEstudiante
{
    var $idEstudiante;
    var $falta;
    var $actitud;
    var $trabajo;
    var $observacion;
    var $fecha;

    /**
     * @return mixed
     */
    public function getIdEstudiante()
    {
        return $this->idEstudiante;
    }

    /**
     * @param mixed $idEstudiante
     */
    public function setIdEstudiante($idEstudiante)
    {
        $this->idEstudiante = $idEstudiante;
    }
/**
     * @return mixed
     */
    public function getTrabajo()
    {
        return $this->trabajo;
    }

    /**
     * @param mixed $idEstudiante
     */
    public function setTrabajo($trabajo)
    {
        $this->trabajo = $trabajo;
    }
    /**
     * @return mixed
     */
    public function getFalta()
    {
        return $this->falta;
    }

    /**
     * @param mixed $falta
     */
    public function setFalta($falta)
    {
        $this->falta = $falta;
    }

    /**
     * @return mixed
     */
    public function getActitud()
    {
        return $this->actitud;
    }

    /**
     * @param mixed $actitud
     */
    public function setActitud($actitud)
    {
        $this->actitud = $actitud;
    }

    /**
     * @return mixed
     */
    public function getObservacion()
    {
        return $this->observacion;
    }

    /**
     * @param mixed $observacion
     */
    public function setObservacion($observacion)
    {
        $this->observacion = $observacion;
    }

    /**
     * @return mixed
     */
    public function getFecha()
    {
        return $this->fecha;
    }

    /**
     * @param mixed $fecha
     */
    public function setFecha($fecha)
    {
        $this->fecha = $fecha;
    }

}