<?php

class Response{

    var $estado;
    var $code;
    var $estudiantes;
    var $estudiante;
    var $msg;
    var $msgError;
    var $control;
    var $controls;
    var $lasId;


    /**
     * @return mixed
     */
    public function getControls()
    {
        return $this->controls;
    }

    /**
     * @param mixed $controls
     */
    public function setControls($controls)
    {
        $this->controls = $controls;
    }

    /**
     * @return mixed
     */
    public function getMsg()
    {
        return $this->msg;
    }

    /**
     * @param mixed $msg
     */
    public function setMsg($msg)
    {
        $this->msg = $msg;
    }

    /**
     * @return mixed
     */
    public function getEstudiante()
    {
        return $this->estudiante;
    }

    /**
     * @param mixed $estudiante
     */
    public function setEstudiante($estudiante)
    {
        $this->estudiante = $estudiante;
    }


    /**
     * @return mixed
     */
    public function getLasId()
    {
        return $this->lasId;
    }

    /**
     * @param mixed $lasId
     */
    public function setLasId($lasId)
    {
        $this->lasId = $lasId;
    }

    /**
     * @return mixed
     */
    public function getControl()
    {
        return $this->control;
    }

    /**
     * @param mixed $control
     */
    public function setControl($control)
    {
        $this->control = $control;
    }

    /**
     * @return mixed
     */
    public function getEstado()
    {
        return $this->estado;
    }

    /**
     * @param mixed $estado
     */
    public function setEstado($estado)
    {
        $this->estado = $estado;
    }

    /**
     * @return mixed
     */
    public function getCode()
    {
        return $this->code;
    }

    /**
     * @param mixed $code
     */
    public function setCode($code)
    {
        $this->code = $code;
    }

    /**
     * @return mixed
     */
    public function getDays()
    {
        return $this->days;
    }

    /**
     * @param mixed $days
     */
    public function setDays($days)
    {
        $this->days = $days;
    }

    /**
     * @return mixed
     */
    public function getEstudiantes()
    {
        return $this->students;
    }

    /**
     * @param mixed $estudiantes
     */
    public function setEstudiantes($estudiantes)
    {
        $this->estudiantes = $estudiantes;
    }

    /**
     * @return mixed
     */
    public function getMsgError()
    {
        return $this->msgError;
    }

    /**
     * @param mixed $msgError
     */
    public function setMsgError($msgError)
    {
        $this->msgError = $msgError;
    }


}