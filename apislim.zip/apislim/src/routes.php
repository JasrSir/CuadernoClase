<?php
// Routes



// CRUD STUDENTS
$app->get('/estudiante', function (\Slim\Http\Request $request,\Slim\Http\Response $response, $args){


    if($request->getHeaderLine("apikey") != "ClaveSecretaProfe12345678"){
        echo "No tienes la clave, muahahaha, estudiantes seguros";
        die();
    }

    $dataBase = DatabaseManager::getPDO();
    $resp = new Response();
    $result = $dataBase->getAllEstudiantes();
    $estudiante = new Estudiante();
    $estudiantes = array();



    for($i = 0; $i < count($result); $i++){

        $estudiante =  new Estudiante();
        $estudiante->setId($result[$i]['id']);
        $estudiante->setApellidos($result[$i]['apellidos']);
        $estudiante->setNombre($result[$i]['nombre']);
        $estudiante->setDireccion($result[$i]['direccion']);
        $estudiante->setCiudad($result[$i]['ciudad']);
        $estudiante->setCodigoPos($result[$i]['codigoPos']);
        $estudiante->setTelefono($result[$i]['telefono']);
        $estudiante->setEmail($result[$i]['email']);
        array_push($estudiantes, $estudiante);
    }


    $resp->setEstudiantes($estudiantes);
    $resp->setEstado(true);

    return $this->response->withJson($resp);
});

$app->post('/estudiante', function ($request, $response){

 if($request->getHeaderLine("apikey") != "ClaveSecretaProfe12345678"){
        echo "No tienes la clave, muahahaha, estudiantes seguros";
        die();
    }

    $dataBase = DatabaseManager::getPDO();
    $resp = new Response();
    $estudiante = new Estudiante();
    $input = $request->getParsedBody();
    $estudiante->setApellidos($input['apellidos']);
    $estudiante->setNombre($input['nombre']);
    $estudiante->setDireccion($input['direccion']);
    $estudiante->setCiudad($input['ciudad']);
    $estudiante->setCodigoPos($input['codigoPos']);
    $estudiante->setTelefono($input['telefono']);
    $estudiante->setEmail($input['email']);

    $result = $dataBase->createEstudiante($estudiante->getApellidos(), $estudiante->getNombre(),  $estudiante->getDireccion(), $estudiante->getCiudad(),
        $estudiante->getCodigoPos(), $estudiante->getTelefono(), $estudiante->getEmail());

    if($result == $dataBase::ERROR_DUPLICATE_ENTRY){
        $resp->setEstado(false);
    }else{
        $resp->setEstado(true);
        $estudiante->setId($result);
        $resp->setEstudiante($estudiante);
    }

    return $this->response->withJson($resp);

});

$app->put('/estudiante/[{id}]', function ($request, $response, $args){

   if($request->getHeaderLine("apikey") != "ClaveSecretaProfe12345678"){
        echo "No tienes la clave, muahahaha, estudiantes seguros";
        die();
    }

    $dataBase = DatabaseManager::getPDO();
    $resp = new Response();
    $estudiante = new Estudiante();
    $input = $request->getParsedBody();
    $estudiante->setId($input['id']);
    $estudiante->setApellidos($input['apellidos']);
    $estudiante->setNombre($input['nombre']);
    $estudiante->setDireccion($input['direccion']);
    $estudiante->setCiudad($input['ciudad']);
    $estudiante->setCodigoPos($input['codigoPos']);
    $estudiante->setTelefono($input['telefono']);
    $estudiante->setEmail($input['email']);

    $result = $dataBase->updateEstudiante($estudiante->getId(),$estudiante->getApellidos(), $estudiante->getNombre(),  $estudiante->getDireccion(), $estudiante->getCiudad(),
        $estudiante->getCodigoPos(), $estudiante->getTelefono(), $estudiante->getEmail());

    if($result == $dataBase::ERROR_DUPLICATE_ENTRY){

        $resp->setEstado(false);

    }else{

        $resp->setEstado(true);
        $resp->setEstudiante($estudiante);
    }

    return $this->response->withJson($resp);
});

$app->delete('/estudiante/[{id}]', function ($request, $response, $args){

  if($request->getHeaderLine("apikey") != "ClaveSecretaProfe12345678"){
        echo "No tienes la clave, muahahaha, estudiantes seguros";
        die();
    }

    $dataBase = DatabaseManager::getPDO();
    $resp = new Response();
    $result = $dataBase->deleteEstudiante($args['id']);

    if($result == $dataBase::RESULT_OK){

        $resp->setEstado(true);

    }else{

        $resp->setEstado(false);
    }
    return $this->response->withJson($resp);

});
//=============================================================================================================//

//CRUD CONTROL
$app->get('/control/[{idEstudiante}]', function (\Slim\Http\Request $request,\Slim\Http\Response $response, $args){
   if($request->getHeaderLine("apikey") != "ClaveSecretaProfe12345678"){
                echo "No tienes la clave, muahahaha, estudiantes seguros";
        die();
    }
    $dataBase = DatabaseManager::getPDO();
    $resp = new Response();

    $rows = $dataBase->selectControlByidEstudiante($args['idEstudiante']);
    $controls = array();


    if($rows != null){

        $resp->setEstado(true);
        $controlEstudiantes = null;
        $controles =array();


        for ($i = 0; $i < count($rows); $i++){
            $controlEstudiantes = new ControlEstudiante();
            $controlEstudiantes->setIdEstudiante($rows[$i]['idEstudiante']);
            $controlEstudiantes->setFalta($rows[$i]['falta']);
            $controlEstudiantes->setActitud($rows[$i]['actitud']);
            $controlEstudiantes->setTrabajo($rows[$i]['trabajo']);
            $controlEstudiantes->setObservacion($rows[$i]['observacion']);
            $controlEstudiantes->setfecha($rows[$i]['fecha']);
            array_push($controles, $controlEstudiantes);
        }
        $resp->setControls($controles);
    }else{
        $resp->setEstado(false);
    }
    return $this->response->withJson($resp);
});

$app->post('/control', function ($request, $response){
  if($request->getHeaderLine("apikey") != "ClaveSecretaProfe12345678"){
        echo "No tienes la clave, muahahaha, estudiantes seguros";
        die();
    }

    $dataBase = DatabaseManager::getPDO();
    $resp = new Response();
    $controlEstudiantes = new ControlEstudiante();
    $input = $request->getParams();
    $controlEstudiantes->setIdEstudiante($input['idEstudiante']);
    $controlEstudiantes->setFalta($input['falta']);
    $controlEstudiantes->setActitud($input['actitud']);
    $controlEstudiantes->setTrabajo($input['trabajo']);
    $controlEstudiantes->setObservacion($input['observacion']);
    $controlEstudiantes->setFecha($input['fecha']);
    
    $result = $dataBase->addControl($controlEstudiantes->getIdEstudiante(), $controlEstudiantes->getFalta(), $controlEstudiantes->getActitud(),
        $controlEstudiantes->getTrabajo(), $controlEstudiantes->getObservacion(), $controlEstudiantes->getFecha());

    if($result != $dataBase::RESULT_OK){

        $resp->setEstado(false);
        $resp->setCode($result);

    }else{

        $resp->setEstado(true);
        //$controlEstudiantes->setIdEstudiante($result);
        //$controlEstudiantes->setEstudiante($result);
        //$resp->setControl($controlEstudiantes);
    }

    return $this->response->withJson($resp);

});

$app->put('/control/[{id}]', function ($request, $response, $args){
    if($request->getHeaderLine("apikey") != "ClaveSecretaProfe12345678"){
                echo "No tienes la clave, muahahaha, estudiantes seguros";

        die();
    }

    $dataBase = DatabaseManager::getPDO();
    $resp = new Response();
    $controlEstudiantes = new ControlEstudiante();
    $input = $request->getParams();
    $controlEstudiantes->setIdEstudiante($input['idEstudiante']);
    $controlEstudiantes->setFalta($input['falta']);
    $controlEstudiantes->setActitud($input['actitud']);
    $controlEstudiantes->setTrabajo($input['trabajo']);
    $controlEstudiantes->setObservacion($input['observacion']);
    $controlEstudiantes->setFecha($input['fecha']);
    $result = $dataBase->updateControl($controlEstudiantes->getIdEstudiante(),$controlEstudiantes->getFalta(), $controlEstudiantes->getActitud(), $controlEstudiantes->getTrabajo(),
        $controlEstudiantes->getObservacion(),$controlEstudiantes->getFecha());

    if($result != $dataBase::RESULT_OK){

        $resp->setEstado(false);
        $resp->setCode($result);
        $resp->setMsg($result);

    }else{

        $resp->setEstado(true);
        $controlEstudiantes->setIdEstudiante($result);
        $controlEstudiantes->setEstudiante(null);
        $resp->setControl($controlEstudiantes);
    }

    return $this->response->withJson($resp);
});

//SEND MAIL
$app->post('/mail', function ($request, $response){

    if($request->getHeaderLine("apikey") != "ClaveSecretaProfe12345678"){
        echo "No tienes la clave, muahahaha, estudiantes seguros";
        die();
    }

    $result = new Response();
    $input = $request->getParsedBody();


    $this->mail->IsSMTP();

    try {
        $this->mail->SMTPDebug = 0;
        $this->mail->SMTPAuth = true;

        //$mail->SMTPSecure = "tls";
        $this->mail->SMTPSecure = "ssl";
        $this->mail->Host = "smtp.gmail.com";
        //$mail->Host = "smtp.openmailbox.org";
        //$mail->Port = 587;
        $this->mail->Port = 465;

        $this->mail->Username = $input['from'];
        $this->mail->Password = $input['pwd'];
        $this->mail->AddAddress($input['to']);
        $this->mail->SetFrom($input['from'], 'Alumno Cabreado');
        $this->mail->AddReplyTo($input['from'], 'Alumno Cabreado');
        $this->mail->Subject = $input['subject'];
        $this->mail->AltBody = 'Message in plain text';
        $this->mail->MsgHTML($input['msg']);

        $this->mail->Send();

        $result->setEstado(TRUE);
        $result->setMsg("Mensaje enviado a " . $input['to']);

    } catch (phpmailerException $e) {
        $result->setEstado(FALSE);
        $result->setMsg("Error: " . $e->errorMessage());
    } catch (Exception $e) {
        $result->setEstado(FALSE);
        $result->setMsg("Error: " . $e->getMessage());
    }
    return $this->response->withJson($result);

});
