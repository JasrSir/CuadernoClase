<?php

/**
 * User: Juan Antonio
 * fecha 18/02/17
 */
class DatabaseManager{

    private  $pdo;
    private static $instance;
    const DATABASE = "cuadernoDBjuanantonio";
    const USER = "alumno";
    const PWD = "malaga2017";
    const HOST = "localhost";
    const RESULT_OK = -1;
    const ERROR_DATABASE = -2;
    const ERROR_DUPLICATE_ENTRY = -3;

    private function __construct(){

        $this->pdo = new PDO("mysql:dbname=".self::DATABASE.";host=".self::HOST."", self::USER, self::PWD,
            array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES UTF8"));

        $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    public static function getPDO(){
        if(self::$instance == null){
            self::$instance = new DatabaseManager();
        }
        return self::$instance;
    }

    public function __destruct(){
        $this->pdo = null;
    }

    public function getDays(){

        $rows = null;
        try {
            $sql = "SELECT * FROM days";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute();
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
        }
        return $rows;
    }

    //=================================================================================================//

    //                     METODOS PARA LOS ESTUDIANTES

    public function getAllEstudiantes(){

        $sql = "SELECT * FROM estudiante";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function deleteEstudiante($idEstudiante){

        $result = self::RESULT_OK;

        try {
            $sql = "DELETE FROM estudiante WHERE id = :id";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute(array(':id' => $idEstudiante));
        } catch (Exception $e) {

            $result = self::ERROR_DATABASE;
        }
        return $result;
    }

    public function getEstudianteByEmail($email){

        $result = null;

        try {
            $sql = "SELECT * FROM estudiante WHERE email = :email";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute(array(':email' => $email));
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
        }

        return $result;
    }

    public function createEstudiante($apellidos, $nombre,  $direccion, $ciudad, $codigoPos, $telefono, $email){

        $result = self::ERROR_DATABASE;

        try {
            $sql = "INSERT INTO estudiante ( apellidos,nombre,direccion, ciudad,
          codigoPos, telefono , email) VALUES ( :apellidos,:nombre, :direccion,
          :ciudad, :codigoPos, :telefono, :email)";
            $this->pdo->beginTransaction();
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':apellidos', $apellidos);
            $stmt->bindParam(':nombre', $nombre);
            $stmt->bindParam(':direccion', $direccion);
            $stmt->bindParam(':ciudad', $ciudad);
            $stmt->bindParam(':codigoPos', $codigoPos);
            $stmt->bindParam(':telefono', $telefono);
            $stmt->bindParam(':email', $email);
            $stmt->execute();
            $result = $this->pdo->lastInsertId();
            $this->pdo->commit();

        } catch (Exception $e) {

            $this->pdo->rollBack();
            $result = self::ERROR_DUPLICATE_ENTRY;
        }
        return $result;
    }

    public function updateEstudiante($id,  $apellidos,$nombre, $direccion, $ciudad, $codigoPos, $telefono,$email){

        $result = self::RESULT_OK;

        try {

            $sql = "UPDATE estudiante SET  apellidos = :apellidos, nombre = :nombre, direccion = :direccion,
        ciudad = :ciudad, codigoPos = :codigoPos, telefono = :telefono, email = :email WHERE id = :id";
            $stmt = $this->pdo->prepare($sql);
            
            $stmt->bindParam(':apellidos', $apellidos);
            $stmt->bindParam(':nombre', $nombre);
            $stmt->bindParam(':direccion', $direccion);
            $stmt->bindParam(':ciudad', $ciudad);
            $stmt->bindParam(':codigoPos', $codigoPos);
            $stmt->bindParam(':telefono', $telefono);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':id', $id);
            $stmt->execute();
        } catch (Exception $e) {
            $result = self::ERROR_DUPLICATE_ENTRY;
        }
        return $result;

    }

    //====================================================================================================//



    //===========================================================================================================//

    //              METODOS PARA EL CONTROL DE ESTUDIANTES

    public function addControl($idEstudiante, $falta, $actitud,$trabajo,  $observacion,  $fecha){

        $result = self::ERROR_DATABASE;

        try {
            $sql = "INSERT INTO control (idEstudiante, falta, actitud,trabajo, observacion, fecha)
             VALUES (:idEstudiante, :falta, :actitud, :trabajo, :observacion, :fecha)";
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(':idEstudiante', $idEstudiante);
            $stmt->bindParam(':falta', $falta);
            $stmt->bindParam(':actitud', $actitud);
            $stmt->bindParam(':trabajo', $trabajo);
            $stmt->bindParam(':observacion', $observacion);
            $stmt->bindParam(':fecha', $fecha);
            $stmt->execute();
            $result = self::RESULT_OK;
        } catch (PDOException $err) {
            $e = $stmt->errorInfo();
            if($e[1] == 1062){
                $result = self::ERROR_DUPLICATE_ENTRY;
             //   $result = self::ERROR_DUPLICATE_ENTRY;
            }else{
                $result = $err->getMessage();
            }
        }
        return $result;
    }



    public function selectControlByidEstudiante ( $idEstudiante){
        $result = null;

        try{
            $sql = "SELECT * FROM control WHERE idEstudiante= :idEstudiante ORDER BY fecha DESC";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute(array(':idEstudiante' => $idEstudiante));
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
            } catch (Exception $e) {
        }
        return $result;

    }

    //===========================================================================================================//
}